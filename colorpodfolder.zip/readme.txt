
colorpod software only runs on windows computers.

install colorpod software in the following way

- copy the colorpod folder to c drive so that it becomes c:\colorpod
- before you connect any of the usb cables run the progam CDM21216_Setup.exe . You will need admin rights for this
- Connect two usb cables one to the colorpod and one to the gcode based fdm printer.
- Start the program colorpod3dp.exe
- to connect to the proper comm-ports use util->scan_comms->yes. The software should find comm ports named Marlin and Inkj.
- press save_ini to save the found comm ports
- if you are not working with ultimaker 2 you will have to setup parameters related to your fdm printer in config->fdm
- press home. The printhead should move to the endstops and then to the starting position
- press Z-reset . The colorpod-roller should end up 0.5 to 1mm above the platform. If not adjust config->fdm->zlevelhome.

